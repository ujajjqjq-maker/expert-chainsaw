package xyz.starkmc.starkranks.security;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.scheduler.BukkitTask;
import xyz.starkmc.starkranks.StarkRanks;
import xyz.starkmc.starkranks.discord.DiscordBot;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.regex.Pattern;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * حماية ضد التروجانات اللي تزرع نفسها في البلوقنات:
 *  1) مراقبة ملفات jar في plugins (جديد / تغيّر / انحذف) حتى لو التغيير صار والسيرفر مطفي (baseline).
 *  2) فحص كلاسات كل jar عن نصوص مشبوهة (قابلة للتعديل من config).
 *  3) مراقبة OP: أي لاعب OP مو في القائمة المسموحة ينبَّه عليه (وممكن ينسحب منه OP تلقائياً).
 *
 * ملاحظة: هذا كشف وتنبيه سريع، مو منع مطلق. أي كود يشتغل داخل نفس السيرفر يقدر نظرياً يعدّل ملفاتي.
 */
public class SecurityGuard {

    private record FileState(long size, long mtime, String sha) {}

    private final StarkRanks plugin;
    private final DiscordBot bot;
    private final Map<String, FileState> known = new HashMap<>(); // يُستخدم من ثريد async واحد فقط
    private final Set<String> alertedOps = ConcurrentHashMap.newKeySet();
    private volatile String selfJarName;
    private BukkitTask fileTask;
    private BukkitTask opTask;

    public SecurityGuard(StarkRanks plugin, DiscordBot bot) {
        this.plugin = plugin;
        this.bot = bot;
    }

    public void start() {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("security.enabled", true)) return;

        long interval = Math.max(10, cfg.getLong("security.check-interval-seconds", 60)) * 20L;
        // أول تمريرة (مقارنة مع baseline) ثم مراقبة دورية
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> pass(true));
        fileTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> pass(false), interval, interval);

        if (!allowedOps().isEmpty()) {
            opTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkOps, 100L, 600L);
        }
    }

    public void stop() {
        if (fileTask != null) fileTask.cancel();
        if (opTask != null) opTask.cancel();
    }

    // ───────────────────────── مراقبة ملفات plugins ─────────────────────────

    private Path pluginsDir() {
        return plugin.getDataFolder().getParentFile().toPath();
    }

    private Path baselineFile() {
        return plugin.getDataFolder().toPath().resolve("baseline.txt");
    }

    private void pass(boolean startup) {
        try {
            java.io.File[] jars = pluginsDir().toFile().listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".jar"));
            if (jars == null) return;

            Map<String, String> baseline = startup ? loadBaseline() : null;
            boolean hadBaseline = !startup || baseline != null;
            Set<String> before = startup
                    ? (baseline == null ? Set.of() : new HashSet<>(baseline.keySet()))
                    : new HashSet<>(known.keySet());

            List<String> events = new ArrayList<>();
            boolean alertWorthy = false;
            boolean changed = false;
            Set<String> seen = new HashSet<>();
            List<String> indicators = plugin.getConfig().getStringList("security.suspicious-strings");

            for (java.io.File f : jars) {
                String name = f.getName();
                seen.add(name);
                long size = f.length();
                long mtime = f.lastModified();
                FileState old = known.get(name);
                if (!startup && old != null && old.size() == size && old.mtime() == mtime) continue;

                String sha;
                try {
                    sha = sha256(f.toPath());
                } catch (IOException | java.security.GeneralSecurityException e) {
                    continue; // ملف مقفول/قيد الكتابة، نجرب بالتمريرة الجاية
                }
                String prev = startup ? (baseline == null ? null : baseline.get(name)) : (old == null ? null : old.sha());
                boolean isNew = prev == null;
                boolean isModified = prev != null && !prev.equals(sha);

                if (selfJarName == null && isSelfJar(f.toPath())) selfJarName = name;
                if (name.equals(selfJarName)) {
                    String trusted = trustedSha();
                    if (trusted == null) {
                        saveTrusted(f.toPath(), sha); // أول مرة: نحفظ نسخة موثوقة من الـ jar
                    } else if (!sha.equals(trusted)) {
                        if (startup) {
                            events.add(msg("sec-line-self-changed"));
                            alertWorthy = true;
                        } else if (isModified && plugin.getConfig().getBoolean("security.self-heal", true)) {
                            try {
                                Files.copy(trustedJar(), f.toPath(), StandardCopyOption.REPLACE_EXISTING);
                                events.add(msg("sec-line-self-restored").replace("{file}", name));
                                alertWorthy = true;
                                changed = true;
                                known.put(name, new FileState(f.length(), f.lastModified(), trusted));
                                continue;
                            } catch (IOException e) {
                                plugin.getLogger().severe("فشل استرجاع النسخة الموثوقة: " + e.getMessage());
                            }
                        }
                    }
                }

                if (hadBaseline && isNew) {
                    events.add(msg("sec-line-new").replace("{file}", name));
                    alertWorthy = true;
                    changed = true;
                } else if (hadBaseline && isModified) {
                    events.add(msg("sec-line-modified").replace("{file}", name));
                    alertWorthy = true;
                    changed = true;
                } else if (!hadBaseline) {
                    changed = true;
                }
                known.put(name, new FileState(size, mtime, sha));

                if (startup || isNew || isModified) {
                    Set<String> found = scanJar(f.toPath(), indicators);
                    if (!found.isEmpty()) {
                        events.add(msg("sec-line-suspicious").replace("{file}", name)
                                .replace("{found}", String.join(", ", found)));
                        alertWorthy = true;
                        if (plugin.getConfig().getBoolean("security.auto-quarantine", false) && !name.equals(selfJarName)) {
                            try {
                                Path q = plugin.getDataFolder().toPath().resolve("quarantine");
                                Files.createDirectories(q);
                                Files.move(f.toPath(), q.resolve(name + "." + System.currentTimeMillis() + ".quarantined"),
                                        StandardCopyOption.REPLACE_EXISTING);
                                events.add(msg("sec-line-quarantined").replace("{file}", name));
                                known.remove(name);
                                changed = true;
                            } catch (IOException e) {
                                events.add(msg("sec-line-quarantine-failed").replace("{file}", name));
                            }
                        }
                    }
                }
            }

            if (hadBaseline) {
                for (String name : before) {
                    if (!seen.contains(name)) {
                        events.add(msg("sec-line-deleted").replace("{file}", name));
                        changed = true;
                    }
                }
            }
            known.keySet().removeIf(n -> !seen.contains(n));

            if (changed) saveBaseline();

            if (!events.isEmpty()) {
                StringBuilder sb = new StringBuilder(msg("sec-files-head")
                        .replace("{mentions}", alertWorthy ? mentions() : "").trim()).append("\n");
                events.forEach(e -> sb.append(e).append("\n"));
                String text = sb.toString().trim();
                plugin.getLogger().severe(text.replace("\n", " | "));
                bot.sendAlert(text);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("فحص الأمان فشل: " + e);
        }
    }

    // ───────────────────────── نسخة موثوقة من jar البلوقن نفسه ─────────────────────────

    private Path trustedJar() {
        return plugin.getDataFolder().toPath().resolve("trusted").resolve("own.jar");
    }

    private Path trustedShaFile() {
        return plugin.getDataFolder().toPath().resolve("trusted").resolve("own.sha");
    }

    private String trustedSha() {
        try {
            if (!Files.exists(trustedJar()) || !Files.exists(trustedShaFile())) return null;
            return Files.readString(trustedShaFile(), StandardCharsets.UTF_8).trim();
        } catch (IOException e) {
            return null;
        }
    }

    private void saveTrusted(Path liveJar, String sha) {
        try {
            Files.createDirectories(trustedJar().getParent());
            Files.copy(liveJar, trustedJar(), StandardCopyOption.REPLACE_EXISTING);
            Files.writeString(trustedShaFile(), sha, StandardCharsets.UTF_8);
        } catch (IOException e) {
            plugin.getLogger().warning("ما قدرت أحفظ النسخة الموثوقة: " + e.getMessage());
        }
    }

    private boolean isSelfJar(Path jar) {
        try (ZipFile zf = new ZipFile(jar.toFile())) {
            ZipEntry e = zf.getEntry("plugin.yml");
            if (e == null) return false;
            String y = new String(zf.getInputStream(e).readAllBytes(), StandardCharsets.UTF_8);
            return Pattern.compile("(?m)^name:\\s*['\"]?" + Pattern.quote(plugin.getName()) + "['\"]?\\s*$").matcher(y).find();
        } catch (IOException | RuntimeException ex) {
            return false;
        }
    }

    /** من الكونسل: يثبّت الـ jar الحالي كنسخة موثوقة (بعد تحديث شرعي) */
    public String trust() {
        String name = selfJarName;
        if (name == null) return "لسا ما حددت ملف البلوقن، جرب بعد دقيقة.";
        Path live = pluginsDir().resolve(name);
        try {
            saveTrusted(live, sha256(live));
            return "تم تثبيت الـ jar الحالي كنسخة موثوقة.";
        } catch (IOException | java.security.GeneralSecurityException e) {
            return "فشل: " + e.getMessage();
        }
    }

    /** من الكونسل: يرجّع النسخة الموثوقة مكان الـ jar الحالي (بعدها أعد تشغيل السيرفر) */
    public String restore() {
        String name = selfJarName;
        if (name == null) return "لسا ما حددت ملف البلوقن، جرب بعد دقيقة.";
        if (trustedSha() == null) return "ما فيه نسخة موثوقة محفوظة.";
        try {
            Files.copy(trustedJar(), pluginsDir().resolve(name), StandardCopyOption.REPLACE_EXISTING);
            return "تم استرجاع النسخة الموثوقة. أعد تشغيل السيرفر.";
        } catch (IOException e) {
            return "فشل: " + e.getMessage();
        }
    }

    private Map<String, String> loadBaseline() {
        Path p = baselineFile();
        if (!Files.exists(p)) return null;
        Map<String, String> m = new HashMap<>();
        try {
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                int i = line.lastIndexOf('\t');
                if (i > 0) m.put(line.substring(0, i), line.substring(i + 1).trim());
            }
        } catch (IOException e) {
            return null;
        }
        return m;
    }

    private void saveBaseline() {
        try {
            Files.createDirectories(baselineFile().getParent());
            List<String> lines = new ArrayList<>();
            new TreeMap<>(known).forEach((n, st) -> lines.add(n + "\t" + st.sha()));
            Files.write(baselineFile(), lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            plugin.getLogger().warning("ما قدرت أحفظ baseline: " + e.getMessage());
        }
    }

    private static String sha256(Path file) throws IOException, java.security.GeneralSecurityException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    /** يدور في ملفات .class داخل الـ jar عن النصوص المشبوهة */
    private static Set<String> scanJar(Path jar, List<String> indicators) {
        Set<String> found = new LinkedHashSet<>();
        if (indicators.isEmpty()) return found;
        try (ZipFile zf = new ZipFile(jar.toFile())) {
            var entries = zf.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement();
                if (e.isDirectory() || !e.getName().endsWith(".class")) continue;
                if (e.getSize() > 8_000_000L) continue;
                String content;
                try (InputStream in = zf.getInputStream(e)) {
                    content = new String(in.readAllBytes(), StandardCharsets.ISO_8859_1);
                }
                for (String ind : indicators) {
                    if (!ind.isBlank() && content.contains(ind)) found.add(ind);
                }
                if (found.size() == indicators.size()) break;
            }
        } catch (IOException | RuntimeException ignored) {
            // jar تالف أو مو قابل للقراءة؛ نتجاهله
        }
        return found;
    }

    // ───────────────────────── مراقبة OP ─────────────────────────

    private Set<String> allowedOps() {
        Set<String> s = new HashSet<>();
        for (String n : plugin.getConfig().getStringList("security.allowed-ops")) {
            if (!n.isBlank()) s.add(n.toLowerCase(Locale.ROOT).trim());
        }
        return s;
    }

    private void checkOps() {
        Set<String> allowed = allowedOps();
        if (allowed.isEmpty()) return;
        boolean autoDeop = plugin.getConfig().getBoolean("security.auto-deop", false);
        Set<String> current = new HashSet<>();
        for (OfflinePlayer op : Bukkit.getOperators()) {
            String name = op.getName() != null ? op.getName() : op.getUniqueId().toString();
            current.add(name.toLowerCase(Locale.ROOT));
            if (allowed.contains(name.toLowerCase(Locale.ROOT))) continue;
            if (!alertedOps.add(name.toLowerCase(Locale.ROOT))) continue;
            if (autoDeop) op.setOp(false);
            String text = msg("sec-op")
                    .replace("{mentions}", mentions())
                    .replace("{player}", name)
                    .replace("{action}", msg(autoDeop ? "sec-op-removed" : "sec-op-kept"));
            plugin.getLogger().severe("OP غير مسموح: " + name);
            bot.sendAlert(text.trim());
        }
        alertedOps.retainAll(current);
    }

    // ───────────────────────── أدوات ─────────────────────────

    private String mentions() {
        FileConfiguration cfg = plugin.getConfig();
        StringBuilder sb = new StringBuilder();
        if (cfg.getBoolean("alerts.mention-authorized", true)) {
            for (String id : cfg.getStringList("authorized-users")) sb.append("<@").append(id).append("> ");
        }
        for (String id : cfg.getStringList("alerts.mention-roles")) sb.append("<@&").append(id).append("> ");
        return sb.toString().trim();
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages." + key, key);
    }
}
