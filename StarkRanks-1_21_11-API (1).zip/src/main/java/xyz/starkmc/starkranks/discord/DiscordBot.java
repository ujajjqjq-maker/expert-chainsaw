package xyz.starkmc.starkranks.discord;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.entities.channel.middleman.MessageChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.requests.GatewayIntent;
import xyz.starkmc.starkranks.StarkRanks;
import xyz.starkmc.starkranks.rank.RankService;
import xyz.starkmc.starkranks.rank.RankService.Holder;
import xyz.starkmc.starkranks.rank.RankService.Outcome;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DiscordBot extends ListenerAdapter {
    private static final int MAX_LEN = 1900;

    private final StarkRanks plugin;
    private final RankService ranks;
    private JDA jda;
    private String channelId = "";

    public DiscordBot(StarkRanks plugin, RankService ranks) {
        this.plugin = plugin;
        this.ranks = ranks;
    }

    public boolean start(String token) {
        try {
            this.channelId = plugin.getConfig().getString("discord.channel-id", "");
            this.jda = JDABuilder.createDefault(token)
                    .enableIntents(GatewayIntent.GUILD_MESSAGES, GatewayIntent.MESSAGE_CONTENT)
                    .addEventListeners(this)
                    .build();
            this.jda.awaitReady();
            plugin.getLogger().info("Discord bot متصل: " + jda.getSelfUser().getAsTag());
            return true;
        } catch (Exception e) {
            plugin.getLogger().severe("فشل Discord bot: " + e.getMessage());
            return false;
        }
    }

    public void shutdown() {
        if (jda != null) {
            jda.shutdown();
        }
    }

    /** يرسل في قناة الرتب المحددة بالكونفج */
    public void sendMessage(String msg) {
        if (jda == null || channelId.isEmpty()) return;
        TextChannel ch = jda.getTextChannelById(channelId);
        if (ch != null) {
            sendChunks(ch, msg);
        }
    }

    /** يرسل تنبيه في قناة الإدارة (alerts.channel-id)، وإذا فاضي ففي قناة الرتب */
    public void sendAlert(String msg) {
        if (jda == null) return;
        String id = plugin.getConfig().getString("alerts.channel-id", "");
        if (id == null || id.isBlank() || id.equals("YOUR_ALERT_CHANNEL_ID_HERE")) id = channelId;
        if (id.isEmpty()) return;
        TextChannel ch = jda.getTextChannelById(id);
        if (ch != null) sendChunks(ch, msg);
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;
        if (!event.getChannel().getId().equals(channelId)) return;
        List<String> auth = plugin.getConfig().getStringList("authorized-users");
        if (!auth.contains(event.getAuthor().getId())) return;

        String raw = event.getMessage().getContentRaw().trim();
        if (raw.isEmpty()) return;
        String[] args = raw.split("\\s+");

        switch (args[0]) {
            case "عطي" -> cmdGive(event, args);
            case "شيل" -> cmdRemove(event, args);
            case "عرض" -> cmdList(event, args);
            case "صلاحيات" -> cmdPerms(event, args);
            case "لاعب" -> cmdPlayer(event, args);
            case "ورث" -> cmdInherit(event, args);
            case "فك" -> cmdUninherit(event, args);
            case "ساعد" -> reply(event, msg("help"));
            default -> reply(event, msg("bad-usage"));
        }
    }

    // ───────────────────────── الأوامر ─────────────────────────

    private void cmdGive(MessageReceivedEvent event, String[] args) {
        if (args.length < 3) {
            reply(event, msg("bad-usage"));
            return;
        }
        Duration dur = null;
        if (args.length >= 4) {
            dur = parseDuration(String.join("", java.util.Arrays.copyOfRange(args, 3, args.length)));
            if (dur == null) {
                reply(event, msg("bad-hours"));
                return;
            }
        }
        final Duration d = dur;
        ranks.give(args[1], args[2], d).whenComplete((out, err) -> {
            if (err != null) {
                fail(event, err);
                return;
            }
            reply(event, outcomeMessage(out, d == null ? "given" : "given-temp", d == null ? null : durationStr(d)));
        });
    }

    /**
     * يقبل: 5h / 2d / 30m / 1d12h / 1d 12h 30m ، والرقم لحاله = ساعات (للتوافق مع القديم).
     * يرجع null لو الصيغة غلط أو المدة صفر.
     */
    private static Duration parseDuration(String raw) {
        String t = raw.toLowerCase().trim();
        if (t.isEmpty()) return null;
        try {
            if (t.matches("\\d{1,6}")) {
                long h = Long.parseLong(t);
                return h > 0 ? Duration.ofHours(h) : null;
            }
            if (!t.matches("(\\d{1,6}[dhm])+")) return null;
            Duration total = Duration.ZERO;
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,6})([dhm])").matcher(t);
            while (m.find()) {
                long n = Long.parseLong(m.group(1));
                total = total.plus(switch (m.group(2)) {
                    case "d" -> Duration.ofDays(n);
                    case "h" -> Duration.ofHours(n);
                    default -> Duration.ofMinutes(n);
                });
            }
            return total.isZero() ? null : total;
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** 2d 5h 30m (الأجزاء الصفرية ما تظهر) */
    private static String durationStr(Duration d) {
        long days = d.toDays();
        long hours = d.toHoursPart();
        long mins = d.toMinutesPart();
        StringBuilder sb = new StringBuilder();
        if (days > 0) sb.append(days).append("d ");
        if (hours > 0) sb.append(hours).append("h ");
        if (mins > 0) sb.append(mins).append("m ");
        return sb.toString().trim();
    }

    private void cmdRemove(MessageReceivedEvent event, String[] args) {
        if (args.length < 3) {
            reply(event, msg("bad-usage"));
            return;
        }
        ranks.remove(args[1], args[2]).whenComplete((out, err) -> {
            if (err != null) {
                fail(event, err);
                return;
            }
            reply(event, outcomeMessage(out, "removed", null));
        });
    }

    /** ورث <رتبة1> <رتبة2> — رتبة2 ترث من رتبة1 (parent في LuckPerms) */
    private void cmdInherit(MessageReceivedEvent event, String[] args) {
        if (args.length < 3) {
            reply(event, msg("bad-usage"));
            return;
        }
        if (args[1].equalsIgnoreCase(args[2])) {
            reply(event, msg("inherit-same"));
            return;
        }
        ranks.inherit(args[1], args[2]).whenComplete((out, err) -> {
            if (err != null) {
                fail(event, err);
                return;
            }
            if (out.status() == RankService.Status.NO_GROUP) {
                reply(event, msg("no-group").replace("{rank}", out.missing()));
                return;
            }
            String key = switch (out.status()) {
                case OK -> "inherit-ok";
                case LOOP -> "inherit-loop";
                default -> "inherit-already";
            };
            reply(event, msg(key).replace("{parent}", out.parent()).replace("{child}", out.child()));
        });
    }

    /** فك <رتبة1> <رتبة2> — رتبة2 ما عاد ترث من رتبة1 */
    private void cmdUninherit(MessageReceivedEvent event, String[] args) {
        if (args.length < 3) {
            reply(event, msg("bad-usage"));
            return;
        }
        if (args[1].equalsIgnoreCase(args[2])) {
            reply(event, msg("inherit-same"));
            return;
        }
        ranks.uninherit(args[1], args[2]).whenComplete((out, err) -> {
            if (err != null) {
                fail(event, err);
                return;
            }
            if (out.status() == RankService.Status.NO_GROUP) {
                reply(event, msg("no-group").replace("{rank}", out.missing()));
                return;
            }
            String key = out.status() == RankService.Status.OK ? "uninherit-ok" : "uninherit-not";
            reply(event, msg(key).replace("{parent}", out.parent()).replace("{child}", out.child()));
        });
    }

    /** صلاحيات <رتبة> — يعرض الصلاحيات المفعلة للرتبة مباشر من LuckPerms */
    private void cmdPerms(MessageReceivedEvent event, String[] args) {
        if (args.length < 2) {
            reply(event, msg("bad-usage"));
            return;
        }
        ranks.permissions(args[1]).whenComplete((p, err) -> {
            if (err != null) {
                fail(event, err);
                return;
            }
            if (p == null) {
                reply(event, msg("no-group").replace("{rank}", args[1]));
                return;
            }
            StringBuilder sb = new StringBuilder(msg("perms-head").replace("{rank}", p.group())).append("\n");
            if (!p.parents().isEmpty()) {
                sb.append("\n").append(msg("perms-parents")).append(" ")
                        .append(String.join(", ", p.parents())).append("\n");
            }
            if (p.permissions().isEmpty()) {
                sb.append("\n").append(msg("perms-none"));
            } else {
                sb.append("\n").append(msg("perms-count").replace("{count}", String.valueOf(p.permissions().size()))).append("\n");
                for (String perm : p.permissions().keySet()) {
                    sb.append("✅ `").append(perm).append("`\n");
                }
            }
            sendChunks(event.getChannel(), sb.toString().trim());
        });
    }

    /** لاعب <اسم> — كل رتب اللاعب مع الوقت المتبقي للمؤقتة */
    private void cmdPlayer(MessageReceivedEvent event, String[] args) {
        if (args.length < 2) {
            reply(event, msg("bad-usage"));
            return;
        }
        List<String> hidden = plugin.getConfig().getStringList("display.hidden-groups");
        ranks.playerRanks(args[1], hidden).whenComplete((pr, err) -> {
            if (err != null) {
                fail(event, err);
                return;
            }
            if (pr == null) {
                reply(event, msg("no-player").replace("{player}", args[1]));
                return;
            }
            StringBuilder sb = new StringBuilder(msg("player-head").replace("{player}", pr.player())).append("\n");
            if (pr.ranks().isEmpty()) {
                sb.append("\n").append(msg("player-none"));
            } else {
                for (Holder h : pr.ranks()) {
                    sb.append(msg("player-entry")
                            .replace("{rank}", h.name())
                            .replace("{remaining}", remainingStr(h.expiry()))).append("\n");
                }
            }
            sendChunks(event.getChannel(), sb.toString().trim());
        });
    }

    /** عرض [رتبة] — كل شيء مباشر من LuckPerms */
    private void cmdList(MessageReceivedEvent event, String[] args) {
        String only = args.length >= 2 ? args[1] : null;
        List<String> hidden = plugin.getConfig().getStringList("display.hidden-groups");

        ranks.list(only, hidden).whenComplete((map, err) -> {
            if (err != null) {
                fail(event, err);
                return;
            }
            if (map.isEmpty()) {
                reply(event, only != null ? msg("no-group").replace("{rank}", only) : msg("list-empty"));
                return;
            }
            boolean anyone = map.values().stream().anyMatch(l -> !l.isEmpty());
            if (!anyone && only == null) {
                reply(event, msg("list-empty"));
                return;
            }

            StringBuilder sb = new StringBuilder(msg("list-head")).append("\n");
            for (Map.Entry<String, List<Holder>> en : map.entrySet()) {
                List<Holder> holders = en.getValue();
                sb.append("\n**").append(en.getKey()).append("** (").append(holders.size()).append(")\n");
                if (holders.isEmpty()) {
                    sb.append("• ").append(msg("list-none")).append("\n");
                    continue;
                }
                for (Holder holder : holders) {
                    sb.append(msg("list-entry")
                                    .replace("{player}", holder.name())
                                    .replace("{rank}", en.getKey())
                                    .replace("{remaining}", remainingStr(holder.expiry())))
                            .append("\n");
                }
            }
            sendChunks(event.getChannel(), sb.toString().trim());
        });
    }

    // ───────────────────────── أدوات مساعدة ─────────────────────────

    private String outcomeMessage(Outcome out, String okKey, String time) {
        String key = switch (out.status()) {
            case OK -> okKey;
            case NO_PLAYER -> "no-player";
            case NO_GROUP -> "no-group";
            case ALREADY -> "already";
            case NOT_HAVE -> "not-have";
            case LOOP -> "inherit-loop";
        };
        return msg(key)
                .replace("{player}", out.player())
                .replace("{rank}", out.rank())
                .replace("{time}", time == null ? "" : time);
    }

    private void fail(MessageReceivedEvent event, Throwable err) {
        plugin.getLogger().warning("خطأ LuckPerms: " + err);
        reply(event, msg("error"));
    }

    private String remainingStr(Instant expiry) {
        if (expiry == null) return "دائمة";
        Duration d = Duration.between(Instant.now(), expiry);
        if (d.isNegative() || d.isZero()) return "منتهية";
        long days = d.toDays();
        long hours = d.toHoursPart();
        long mins = d.toMinutesPart();
        if (days > 0) return days + "d " + hours + "h";
        if (hours > 0) return hours + "h " + mins + "m";
        return Math.max(mins, 1) + "m";
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages." + key, key);
    }

    private void reply(MessageReceivedEvent event, String text) {
        sendChunks(event.getChannel(), text);
    }

    /** ديسكورد حده 2000 حرف، فنقسم على الأسطر */
    private void sendChunks(MessageChannel ch, String text) {
        List<String> parts = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String line : text.split("\n", -1)) {
            if (cur.length() + line.length() + 1 > MAX_LEN && cur.length() > 0) {
                parts.add(cur.toString());
                cur.setLength(0);
            }
            if (line.length() > MAX_LEN) line = line.substring(0, MAX_LEN);
            cur.append(line).append("\n");
        }
        if (cur.length() > 0) parts.add(cur.toString().trim());
        for (String p : parts) {
            if (!p.isBlank()) ch.sendMessage(p).queue();
        }
    }
}
