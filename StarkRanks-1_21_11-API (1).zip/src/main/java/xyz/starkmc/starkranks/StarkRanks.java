package xyz.starkmc.starkranks;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.starkmc.starkranks.alert.DangerAlert;
import xyz.starkmc.starkranks.discord.DiscordBot;
import xyz.starkmc.starkranks.rank.RankService;
import xyz.starkmc.starkranks.security.SecurityGuard;

public class StarkRanks extends JavaPlugin {
    private static StarkRanks instance;
    private DiscordBot discordBot;
    private LuckPerms luckPerms;
    private RankService rankService;
    private DangerAlert dangerAlert;
    private SecurityGuard securityGuard;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        if (getServer().getPluginManager().getPlugin("LuckPerms") == null) {
            getLogger().severe("LuckPerms مو موجود!");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        this.luckPerms = LuckPermsProvider.get();

        String token = getConfig().getString("discord.token", "");
        if (token.isEmpty() || token.equals("YOUR_BOT_TOKEN_HERE")) {
            getLogger().severe("ضع توكن البوت في config.yml!");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.rankService = new RankService(this, luckPerms);
        this.discordBot = new DiscordBot(this, rankService);
        if (!discordBot.start(token)) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        // إشعار انتهاء الرتب المؤقتة (يعتمد على أحداث LuckPerms نفسها)
        rankService.start(discordBot::sendMessage);
        this.dangerAlert = new DangerAlert(this, luckPerms, discordBot);
        dangerAlert.start();
        this.securityGuard = new SecurityGuard(this, discordBot);
        securityGuard.start();
        getLogger().info("StarkRanks شغال (LuckPerms API).");
    }

    @Override
    public void onDisable() {
        if (securityGuard != null) {
            securityGuard.stop();
        }
        if (dangerAlert != null) {
            dangerAlert.stop();
        }
        if (rankService != null) {
            rankService.stop();
        }
        if (discordBot != null) {
            discordBot.shutdown();
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("starkranks.admin")) {
            sender.sendMessage("§cما عندك صلاحية.");
            return true;
        }
        if (args.length > 0 && (args[0].equalsIgnoreCase("trust") || args[0].equalsIgnoreCase("restore"))) {
            if (!(sender instanceof org.bukkit.command.ConsoleCommandSender) || securityGuard == null) {
                sender.sendMessage("§cهذا الأمر من الكونسل فقط.");
                return true;
            }
            sender.sendMessage(args[0].equalsIgnoreCase("trust") ? securityGuard.trust() : securityGuard.restore());
            return true;
        }
        reloadConfig();
        sender.sendMessage("§aتم reload الكونفج.");
        return true;
    }

    public static StarkRanks getInstance() {
        return instance;
    }

    public DiscordBot getDiscordBot() {
        return discordBot;
    }

    public LuckPerms getLuckPerms() {
        return luckPerms;
    }

    public RankService getRankService() {
        return rankService;
    }
}
