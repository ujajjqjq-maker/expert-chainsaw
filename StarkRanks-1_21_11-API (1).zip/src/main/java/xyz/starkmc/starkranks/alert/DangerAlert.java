package xyz.starkmc.starkranks.alert;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.actionlog.Action;
import net.luckperms.api.event.EventSubscription;
import net.luckperms.api.event.log.LogBroadcastEvent;
import net.luckperms.api.event.node.NodeAddEvent;
import net.luckperms.api.event.node.NodeMutateEvent;
import net.luckperms.api.event.node.NodeRemoveEvent;
import net.luckperms.api.model.PermissionHolder;
import net.luckperms.api.model.data.DataType;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.types.PermissionNode;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import xyz.starkmc.starkranks.StarkRanks;
import xyz.starkmc.starkranks.discord.DiscordBot;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.Map;

/**
 * تنبيه تلقائي لما أحد يضيف/يشيل صلاحية خطرة (من أي رتبة أو لاعب).
 * الكشف من أحداث LuckPerms (Node Add/Remove)، ومعرفة "من سواها" من سجل LuckPerms (LogBroadcastEvent).
 */
public class DangerAlert {
    private static final UUID CONSOLE_UUID = new UUID(0L, 0L);
    private static final long ACTION_KEEP_MS = 60_000L;

    private record Logged(Action action, String origin, long time) {}

    private record Change(boolean added, String node, boolean isGroup, String targetName,
                          Instant expiry, long time) {}

    private final StarkRanks plugin;
    private final LuckPerms lp;
    private final DiscordBot bot;
    private final ConcurrentLinkedDeque<Logged> recentActions = new ConcurrentLinkedDeque<>();
    private final Map<String, Long> dedupe = new ConcurrentHashMap<>();
    private final List<EventSubscription<?>> subs = new ArrayList<>();

    public DangerAlert(StarkRanks plugin, LuckPerms lp, DiscordBot bot) {
        this.plugin = plugin;
        this.lp = lp;
        this.bot = bot;
    }

    public void start() {
        if (!plugin.getConfig().getBoolean("alerts.enabled", true)) return;
        var bus = lp.getEventBus();
        subs.add(bus.subscribe(plugin, LogBroadcastEvent.class, this::onLog));
        subs.add(bus.subscribe(plugin, NodeAddEvent.class, e -> onNode(e, true)));
        subs.add(bus.subscribe(plugin, NodeRemoveEvent.class, e -> onNode(e, false)));
    }

    public void stop() {
        subs.forEach(EventSubscription::close);
        subs.clear();
    }

    // ───────────────────────── سجل LuckPerms (من سوى الإجراء) ─────────────────────────

    private void onLog(LogBroadcastEvent e) {
        long now = System.currentTimeMillis();
        recentActions.removeIf(l -> now - l.time() > ACTION_KEEP_MS);
        recentActions.addFirst(new Logged(e.getEntry(), e.getOrigin().name(), now));
    }

    // ───────────────────────── كشف التغيير ─────────────────────────

    private void onNode(NodeMutateEvent e, boolean added) {
        if (e.getDataType() != DataType.NORMAL) return;
        Node node = added ? ((NodeAddEvent) e).getNode() : ((NodeRemoveEvent) e).getNode();
        if (node.getType() != NodeType.PERMISSION) return;
        if (!node.getValue()) return;               // نتجاهل الصلاحيات الممنوعة (false)
        if (node.hasExpired()) return;              // انتهاء مؤقت تلقائي مو تعديل يدوي
        PermissionNode pn = (PermissionNode) node;
        String perm = pn.getPermission();
        if (!isDangerous(perm)) return;

        PermissionHolder target = e.getTarget();
        boolean isGroup = e.isGroup();
        String targetName;
        if (target instanceof Group g) targetName = g.getName();
        else if (target instanceof User u) targetName = u.getUsername() != null ? u.getUsername() : u.getUniqueId().toString();
        else return;

        long now = System.currentTimeMillis();
        String key = (added ? "+" : "-") + isGroup + ":" + targetName.toLowerCase() + ":" + perm.toLowerCase();
        dedupe.values().removeIf(t -> now - t > 5_000L);
        if (dedupe.putIfAbsent(key, now) != null) return;

        Change c = new Change(added, perm, isGroup, targetName, node.getExpiry(), now);
        // ننتظر ثانية عشان يوصل سجل LuckPerms ونعرف من سوى الإجراء
        Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, () -> send(c), 20L);
    }

    /** مطابقة بسيطة: تطابق تام، أو نمط ينتهي بـ * (مثل luckperms.*)، و "*" لحاله دائماً خطر */
    private boolean isDangerous(String perm) {
        String p = perm.toLowerCase(Locale.ROOT);
        if (p.equals("*")) return true;
        for (String pattern : plugin.getConfig().getStringList("alerts.dangerous-permissions")) {
            String pat = pattern.toLowerCase(Locale.ROOT).trim();
            if (pat.isEmpty()) continue;
            if (pat.equals(p)) return true;
            if (pat.endsWith("*") && p.startsWith(pat.substring(0, pat.length() - 1))) return true;
        }
        return false;
    }

    // ───────────────────────── الإرسال ─────────────────────────

    private Logged findActor(Change c) {
        String perm = c.node().toLowerCase(Locale.ROOT);
        for (Logged l : recentActions) { // الأحدث أول
            if (Math.abs(l.time() - c.time()) > 15_000L) continue;
            Action a = l.action();
            if (!a.getTarget().getName().equalsIgnoreCase(c.targetName())) continue;
            if (!a.getDescription().toLowerCase(Locale.ROOT).contains(perm)) continue;
            return l;
        }
        return null;
    }

    private void send(Change c) {
        FileConfiguration cfg = plugin.getConfig();

        String actor;
        Logged l = findActor(c);
        if (l == null) {
            actor = msg("alert-actor-unknown");
        } else {
            Action.Source src = l.action().getSource();
            boolean console = CONSOLE_UUID.equals(src.getUniqueId()) || src.getName().equalsIgnoreCase("console");
            if (console) {
                actor = msg("alert-actor-console");
            } else if (l.origin().contains("API")) {
                actor = msg("alert-actor-api").replace("{name}", src.getName());
            } else {
                actor = msg("alert-actor-player").replace("{name}", src.getName());
            }
        }

        String target = (c.isGroup() ? msg("alert-target-group") : msg("alert-target-user"))
                .replace("{name}", c.targetName());

        String expiry = "";
        if (c.expiry() != null) {
            Duration d = Duration.between(Instant.now(), c.expiry());
            expiry = msg("alert-temp").replace("{time}", fmt(d));
        }

        StringBuilder mentions = new StringBuilder();
        if (cfg.getBoolean("alerts.mention-authorized", true)) {
            for (String id : cfg.getStringList("authorized-users")) mentions.append("<@").append(id).append("> ");
        }
        for (String id : cfg.getStringList("alerts.mention-roles")) mentions.append("<@&").append(id).append("> ");

        String text = msg(c.added() ? "alert-added" : "alert-removed")
                .replace("{mentions}", mentions.toString().trim())
                .replace("{node}", c.node())
                .replace("{target}", target)
                .replace("{actor}", actor)
                .replace("{temp}", expiry);
        bot.sendAlert(text.trim());
    }

    private static String fmt(Duration d) {
        if (d.isNegative() || d.isZero()) return "0m";
        long days = d.toDays();
        long hours = d.toHoursPart();
        long mins = d.toMinutesPart();
        if (days > 0) return days + "d " + hours + "h";
        if (hours > 0) return hours + "h " + mins + "m";
        return Math.max(mins, 1) + "m";
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages." + key, key);
    }
}
