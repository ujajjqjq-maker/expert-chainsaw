package xyz.starkmc.starkranks.rank;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.event.EventSubscription;
import net.luckperms.api.event.node.NodeRemoveEvent;
import net.luckperms.api.model.data.DataMutateResult;
import net.luckperms.api.model.data.TemporaryNodeMergeStrategy;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.model.user.UserManager;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.NodeType;
import net.luckperms.api.node.matcher.NodeMatcher;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/**
 * كل التعامل مع الرتب يتم عبر LuckPerms API مباشرة (بدون أوامر كونسل).
 * العرض يقرأ الحالة الفعلية من LuckPerms، مو من ملف محلي.
 */
public class RankService {

    public enum Status { OK, NO_PLAYER, NO_GROUP, ALREADY, NOT_HAVE, LOOP }

    public record Outcome(Status status, String player, String rank) {}

    /** expiry == null يعني رتبة دائمة */
    public record Holder(String name, Instant expiry) {}

    /** صلاحيات الرتبة: الاسم الفعلي، الرتب الموروثة، والصلاحيات المفعلة */
    public record Perms(String group, List<String> parents, Map<String, Boolean> permissions) {}

    /** رتب اللاعب: الاسم الفعلي + كل رتبه (name = اسم الرتبة، expiry == null يعني دائمة) */
    public record PlayerRanks(String player, List<Holder> ranks) {}

    /** نتيجة الوراثة: missing = اسم الرتبة غير الموجودة (لو NO_GROUP) */
    public record InheritOutcome(Status status, String missing, String parent, String child) {}

    private final Plugin plugin;
    private final LuckPerms lp;
    private final UserManager users;
    private final Executor async;
    private final Map<String, Long> recentExpired = new ConcurrentHashMap<>();

    private EventSubscription<NodeRemoveEvent> subscription;
    private BukkitTask sweepTask;

    public RankService(Plugin plugin, LuckPerms lp) {
        this.plugin = plugin;
        this.lp = lp;
        this.users = lp.getUserManager();
        this.async = r -> Bukkit.getScheduler().runTaskAsynchronously(plugin, r);
    }

    // ───────────────────────── إعطاء / إزالة ─────────────────────────

    public CompletableFuture<Outcome> give(String playerName, String rankName, Duration duration) {
        // loadGroup يتأكد من التخزين نفسه، مو بس اللي محمّل بالذاكرة
        return lp.getGroupManager().loadGroup(rankName.toLowerCase()).thenCompose(opt -> {
        if (opt.isEmpty()) {
            return CompletableFuture.completedFuture(new Outcome(Status.NO_GROUP, playerName, rankName));
        }
        Group group = opt.get();
        return users.lookupUniqueId(playerName).thenCompose(uuid -> {
            if (uuid == null) {
                return CompletableFuture.completedFuture(new Outcome(Status.NO_PLAYER, playerName, group.getName()));
            }
            return users.loadUser(uuid).thenCompose(user -> {
                InheritanceNode.Builder builder = InheritanceNode.builder(group);
                boolean ok;
                if (duration != null) {
                    builder.expiry(duration);
                    // لو عنده نفس الرتبة مؤقتة، تنضاف المدة الجديدة فوق الباقي
                    ok = user.data().add(builder.build(),
                            TemporaryNodeMergeStrategy.ADD_NEW_DURATION_TO_EXISTING).wasSuccessful();
                } else {
                    ok = user.data().add(builder.build()).wasSuccessful();
                }
                String shown = displayName(user, playerName);
                if (!ok) {
                    return CompletableFuture.completedFuture(new Outcome(Status.ALREADY, shown, group.getName()));
                }
                return save(user).thenApply(v -> new Outcome(Status.OK, shown, group.getName()));
            });
        });
        });
    }

    public CompletableFuture<Outcome> remove(String playerName, String rankName) {
        return users.lookupUniqueId(playerName).thenCompose(uuid -> {
            if (uuid == null) {
                return CompletableFuture.completedFuture(new Outcome(Status.NO_PLAYER, playerName, rankName));
            }
            return users.loadUser(uuid).thenCompose(user -> {
                List<InheritanceNode> mine = user.getNodes(NodeType.INHERITANCE).stream()
                        .filter(n -> n.getGroupName().equalsIgnoreCase(rankName))
                        .toList();
                String shown = displayName(user, playerName);
                if (mine.isEmpty()) {
                    return CompletableFuture.completedFuture(new Outcome(Status.NOT_HAVE, shown, rankName));
                }
                // نشيل الدائمة والمؤقتة مع بعض
                mine.forEach(n -> user.data().remove(n));
                return save(user).thenApply(v -> new Outcome(Status.OK, shown, rankName));
            });
        });
    }

    /** يرجع صلاحيات الرتبة (المباشرة المفعلة فقط) مرتبة أبجدياً، أو null لو الرتبة غير موجودة */
    public CompletableFuture<Perms> permissions(String rankName) {
        return lp.getGroupManager().loadGroup(rankName.toLowerCase()).thenApply(opt -> {
            if (opt.isEmpty()) return null;
            Group g = opt.get();
            List<String> parents = g.getNodes(NodeType.INHERITANCE).stream()
                    .filter(n -> !n.hasExpired())
                    .map(InheritanceNode::getGroupName)
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .toList();
            TreeMap<String, Boolean> perms = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            g.getNodes(NodeType.PERMISSION).stream()
                    .filter(n -> !n.hasExpired() && n.getValue())
                    .forEach(n -> perms.put(n.getPermission(), n.getValue()));
            return new Perms(g.getName(), parents, perms);
        });
    }

    /** كل رتب اللاعب (مرتبة حسب الوزن)؛ يرجع null لو اللاعب غير موجود */
    public CompletableFuture<PlayerRanks> playerRanks(String playerName, Collection<String> hidden) {
        Set<String> hide = new HashSet<>();
        hidden.forEach(h -> hide.add(h.toLowerCase()));
        return users.lookupUniqueId(playerName).thenCompose(uuid -> {
            if (uuid == null) return CompletableFuture.completedFuture((PlayerRanks) null);
            return users.loadUser(uuid).thenApply(user -> {
                List<InheritanceNode> nodes = new ArrayList<>(user.getNodes(NodeType.INHERITANCE));
                Map<String, Integer> weights = new HashMap<>();
                for (InheritanceNode n : nodes) {
                    Group g = lp.getGroupManager().getGroup(n.getGroupName());
                    weights.put(n.getGroupName().toLowerCase(), g == null ? 0 : g.getWeight().orElse(0));
                }
                List<Holder> ranks = nodes.stream()
                        .filter(n -> !n.hasExpired() && !hide.contains(n.getGroupName().toLowerCase()))
                        .sorted(Comparator.comparingInt((InheritanceNode n) -> weights.get(n.getGroupName().toLowerCase())).reversed()
                                .thenComparing(InheritanceNode::getGroupName))
                        .map(n -> new Holder(n.getGroupName(), n.getExpiry()))
                        .toList();
                return new PlayerRanks(displayName(user, playerName), ranks);
            });
        });
    }

    /** يخلي رتبة "child" ترث من رتبة "parent" (parent في LuckPerms)، بدون نسخ صلاحيات */
    public CompletableFuture<InheritOutcome> inherit(String parentName, String childName) {
        var gm = lp.getGroupManager();
        return gm.loadGroup(parentName.toLowerCase()).thenCompose(a -> gm.loadGroup(childName.toLowerCase()).thenCompose(b -> {
            if (a.isEmpty()) {
                return CompletableFuture.completedFuture(new InheritOutcome(Status.NO_GROUP, parentName, parentName, childName));
            }
            if (b.isEmpty()) {
                return CompletableFuture.completedFuture(new InheritOutcome(Status.NO_GROUP, childName, parentName, childName));
            }
            Group parent = a.get();
            Group child = b.get();
            // منع الحلقة: لو الأب نفسه يرث (مباشر أو غير مباشر) من الابن
            boolean loop = parent.getInheritedGroups(net.luckperms.api.query.QueryOptions.nonContextual()).stream()
                    .anyMatch(g -> g.getName().equalsIgnoreCase(child.getName()));
            if (loop) {
                return CompletableFuture.completedFuture(new InheritOutcome(Status.LOOP, null, parent.getName(), child.getName()));
            }
            boolean ok = child.data().add(InheritanceNode.builder(parent).build()).wasSuccessful();
            InheritOutcome out = new InheritOutcome(ok ? Status.OK : Status.ALREADY, null, parent.getName(), child.getName());
            if (!ok) return CompletableFuture.completedFuture(out);
            return gm.saveGroup(child).thenApply(v -> {
                lp.getMessagingService().ifPresent(m -> m.pushUpdate());
                return out;
            });
        }));
    }

    /** يفك الوراثة: رتبة "child" ما عاد ترث من "parent" (الدائمة والمؤقتة) */
    public CompletableFuture<InheritOutcome> uninherit(String parentName, String childName) {
        var gm = lp.getGroupManager();
        return gm.loadGroup(parentName.toLowerCase()).thenCompose(a -> gm.loadGroup(childName.toLowerCase()).thenCompose(b -> {
            if (a.isEmpty()) {
                return CompletableFuture.completedFuture(new InheritOutcome(Status.NO_GROUP, parentName, parentName, childName));
            }
            if (b.isEmpty()) {
                return CompletableFuture.completedFuture(new InheritOutcome(Status.NO_GROUP, childName, parentName, childName));
            }
            Group parent = a.get();
            Group child = b.get();
            List<InheritanceNode> mine = child.getNodes(NodeType.INHERITANCE).stream()
                    .filter(n -> n.getGroupName().equalsIgnoreCase(parent.getName()))
                    .toList();
            if (mine.isEmpty()) {
                return CompletableFuture.completedFuture(new InheritOutcome(Status.NOT_HAVE, null, parent.getName(), child.getName()));
            }
            mine.forEach(n -> child.data().remove(n));
            InheritOutcome out = new InheritOutcome(Status.OK, null, parent.getName(), child.getName());
            return gm.saveGroup(child).thenApply(v -> {
                lp.getMessagingService().ifPresent(m -> m.pushUpdate());
                return out;
            });
        }));
    }

    private CompletableFuture<Void> save(User user) {
        return users.saveUser(user).thenRun(() ->
                // مزامنة باقي السيرفرات (هب، براكتس...) لو فيه messaging service
                lp.getMessagingService().ifPresent(m -> m.pushUserUpdate(user)));
    }

    private static String displayName(User user, String fallback) {
        String n = user.getUsername();
        return n != null ? n : fallback;
    }

    // ───────────────────────── العرض (من LuckPerms الفعلي) ─────────────────────────

    /**
     * يرجع كل الرتب (مرتبة حسب الوزن) ومعها اللاعبين اللي فعلاً عندهم الرتبة الحين.
     *
     * @param onlyRank لو غير null يرجع هالرتبة بس
     * @param hidden   رتب تنخفي من العرض (مثل default)
     */
    public CompletableFuture<LinkedHashMap<String, List<Holder>>> list(String onlyRank, Collection<String> hidden) {
        Set<String> hide = new HashSet<>();
        hidden.forEach(h -> hide.add(h.toLowerCase()));

        return users.searchAll(NodeMatcher.type(NodeType.INHERITANCE)).thenApplyAsync(found -> {
            List<Group> groups = new ArrayList<>(lp.getGroupManager().getLoadedGroups());
            groups.sort(Comparator.comparingInt((Group g) -> g.getWeight().orElse(0)).reversed()
                    .thenComparing(Group::getName));

            LinkedHashMap<String, List<Holder>> result = new LinkedHashMap<>();
            for (Group g : groups) {
                String name = g.getName().toLowerCase();
                if (hide.contains(name)) continue;
                if (onlyRank != null && !name.equalsIgnoreCase(onlyRank)) continue;
                result.put(g.getName(), new ArrayList<>());
            }

            Map<UUID, String> names = new HashMap<>();
            for (Map.Entry<UUID, Collection<InheritanceNode>> e : found.entrySet()) {
                for (InheritanceNode node : e.getValue()) {
                    if (node.hasExpired()) continue;
                    List<Holder> bucket = findBucket(result, node.getGroupName());
                    if (bucket == null) continue;
                    String name = names.computeIfAbsent(e.getKey(), this::resolveName);
                    bucket.add(new Holder(name, node.getExpiry()));
                }
            }
            result.values().forEach(l -> l.sort(Comparator
                    .comparing((Holder h) -> h.expiry() != null) // الدائمة أول
                    .thenComparing(h -> h.name().toLowerCase())));
            return result;
        }, async);
    }

    private static List<Holder> findBucket(Map<String, List<Holder>> map, String group) {
        for (Map.Entry<String, List<Holder>> en : map.entrySet()) {
            if (en.getKey().equalsIgnoreCase(group)) return en.getValue();
        }
        return null;
    }

    private String resolveName(UUID uuid) {
        User loaded = users.getUser(uuid);
        if (loaded != null && loaded.getUsername() != null) return loaded.getUsername();
        try {
            String n = users.lookupUsername(uuid).join();
            if (n != null) return n;
        } catch (Exception ignored) {
        }
        String n = Bukkit.getOfflinePlayer(uuid).getName();
        return n != null ? n : uuid.toString().substring(0, 8);
    }

    // ───────────────────────── انتهاء الرتب المؤقتة ─────────────────────────

    /** يشغّل مراقبة الانتهاء ويرسل الإشعار عبر notifier (رسالة ديسكورد جاهزة). */
    public void start(Consumer<String> notifier) {
        this.subscription = lp.getEventBus().subscribe(plugin, NodeRemoveEvent.class, e -> {
            if (!e.isUser()) return;
            Node node = e.getNode();
            if (!(node instanceof InheritanceNode inh) || !node.hasExpired()) return;
            User user = (User) e.getTarget();

            // منع تكرار الإشعار لو انطلق الحدث مرتين
            long now = System.currentTimeMillis();
            String key = user.getUniqueId() + ":" + inh.getGroupName().toLowerCase();
            recentExpired.values().removeIf(t -> now - t > 10_000L);
            if (recentExpired.putIfAbsent(key, now) != null) return;

            String name = displayName(user, user.getUniqueId().toString());
            notifier.accept(plugin.getConfig().getString("messages.expired", "expired")
                    .replace("{player}", name)
                    .replace("{rank}", inh.getGroupName()));
        });

        // LuckPerms ما ينظف الرتب المنتهية إلا للاعبين المحمّلين؛ هالفحص ينظف الأوفلاين كل دقيقة
        this.sweepTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::sweepExpired, 100L, 1200L);
    }

    private void sweepExpired() {
        users.searchAll(NodeMatcher.type(NodeType.INHERITANCE)).thenAccept(found ->
                found.forEach((uuid, nodes) -> {
                    List<InheritanceNode> expired = nodes.stream().filter(Node::hasExpired).toList();
                    if (expired.isEmpty()) return;
                    users.modifyUser(uuid, u -> expired.forEach(n -> u.data().remove(n)));
                })
        ).exceptionally(t -> {
            plugin.getLogger().warning("فحص الرتب المنتهية فشل: " + t.getMessage());
            return null;
        });
    }

    public void stop() {
        if (subscription != null) subscription.close();
        if (sweepTask != null) sweepTask.cancel();
    }
}
